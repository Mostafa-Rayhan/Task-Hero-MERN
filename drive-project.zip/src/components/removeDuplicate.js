
const removeDuplicate=(arr)=>{
    const uniqueArray = [...new Set(arr)];
 return uniqueArray
}

