

const Loading = () => {
    return (
        <div className="h-screen w-screen flex justify-center items-center font-bold ">
            Loading...
        </div>
    );
};

export default Loading;
